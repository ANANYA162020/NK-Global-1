# Weather-API-web-application using flask
in this project i have made a weather app that would take two inputs two countries and it would also be analyzing data from the backendpart frm (test16.py file) and the connecting file dd.py file and give the output in acordace to that keeping the values provided in py files in analyzation.


link of deployemnt -http://127.0.0.1:5000/ 
(note sometimes the link might not work due to internal error otherwise the app is fine)
 
